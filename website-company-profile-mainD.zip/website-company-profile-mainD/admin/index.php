<?php include("inc_header.php")?>

<h1>Haloo!
    Have Nice Your Day
</h1>
<p>
    Selamat datang <b><?php echo $_SESSION['admin_username']?></b> di halaman Administrasi Pt.Waihury Makmur.
</p>

<?php include("inc_footer.php")?>