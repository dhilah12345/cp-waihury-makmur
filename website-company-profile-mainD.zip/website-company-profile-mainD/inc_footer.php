</div>

    <div id="contact">
        <div class="wrapper">
            <div class="footer">
                
               
                <div class="footer-section">
                    <h3><?php echo ambil_isi_info('3','judul')?></h3>
                    <?php echo ambil_isi_info('3','isi')?>
                </div>
                <div class="footer-section">
                    <h3><?php echo ambil_isi_info('4','judul')?></h3>
                    <?php echo ambil_isi_info('4','isi')?>
                </div>
            </div>
        </div>
    </div>

    <div id="copyright">
        <div class="wrapper">
            &copy; 2019. <b>Pt.Waihury Makmur.</b> Jasa Pengurus Transportasi
        </div>
    </div>
    
</body>
</html>